from django.apps import AppConfig


class GeolocalisationConfig(AppConfig):
    name = 'Geolocalisation'
