

/*

je n ai pas la bonne valeur sur les cercles */
function getCouleur(value){
  if ( value < 0)
    return "red"
  else
    return "blue"
}


function min(data){
  var min = Number.MAX_SAFE_INTEGER

    for ( client in data){
      if ( $.isNumeric(data[client].value) == true &&  data[client].value <min)
          min = data[client].value;
    }

    return min;
}

function max(data){
  var max = Number.MIN_SAFE_INTEGER;

  for ( client in data){
    if ( $.isNumeric(data[client].value) == true &&  data[client].value  > max)
        max = data[client].value;
  }

  return max;
}

function getScale(data){

  var echelle = new Array();
  var min_echelle = 20;
  var max_echelle = 70;
  var client_echelle;

  var min_value = min(data);
  var max_value = max(data);

  for ( client in data){
    echelle[client]= ((data[client].value - min_value )/(max_value - min_value))*(max_echelle -  min_echelle) + min_echelle;
  }
  return echelle;
}


/*
Ce json contient pour chaque adrese les données suivantes :
id: l'identifiant de l'adresse dans la base de donnée
cp: code postale
ville: la ville
chiffre: le choffre d 'affaire ou la marge
*/


function updateMap(){


  bool_cal= $("#ca_label").hasClass("active");
  console.log( "bool_ca: "+bool_cal);

  id_commercial= document.forms["representant_form"].elements[0].value;
  if(id_commercial=="null")// car il recupère la valeur du champs en chaine de caractere
      id_commercial=null;

  id_magasin = document.forms["representant_form"].elements[1].value;
  if(id_magasin=="null")// car il recupère la valeur du champs en chaine de caractere
      id_magasin=null;
  console.log("id_magasin: "+id_magasin);

  id_famille = document.forms["famille_form"].elements[0].value;
  if(id_famille=="null")// car il recupère la valeur du champs en chaine de caractere
      id_famille=null;
  console.log("id_famille: "+id_famille);

  id_sousfamille = document.forms["sous_famille_form"].elements[0].value;
  if(id_sousfamille=="null")// car il recupère la valeur du champs en chaine de caractere
      id_sousfamille=null;
  console.log("id_sousfamille : "+id_sousfamille);



  $.ajax({
    type:"POST",
    url:"/dashboard/sql_get_geoloc_data/",
    data: {
      'filter[]': [null,  id_commercial, id_magasin, id_sousfamille, id_famille ],
      // bool_cal : bool_cal,
    //  'filter[]': [null, null, null, null, null],
      'bool_ca': true
    },
    success: function(json_data){
      var clients = JSON.parse(json_data);


      // Create the map.
      var map = new google.maps.Map(document.getElementById('map_canvas'), {
        zoom: 6,

        center: {lat: 47.090, lng: 0},
      });


      var echelle = getScale(clients);
      var geocoder = new google.maps.Geocoder();

      for (var client in data){
      geocodeAddress(geocoder, data[client],echelle,map);
      }
    }

  })

  }

/* cette foinction recherche la latitude et la longitude d'une addresse et l'affiche sur la carte */
      function geocodeAddress(geocoder, client,echelle_valeur,map) {

          console.log("retour du python :")
          console.log(client)
        //      for (var client in data) {
                // si le Chiffre d'affaire ou la marge est un numérique
                  if ( $.isNumeric(client.value) == true){

                      var address = client.ville + " "+ client.cp  ;
                      // recherche de la latitude et de la longitude
                      geocoder.geocode({'address': address}, function(results, status) {
                  //      console.log(address);

                  var couleur = getCouleur(client.value)
                      // si les coordonnées ont été trouvées
                        if (status === 'OK') {

                            // console.log("localisation courante:")
                            // console.log(client)
                          var mIcon = {
                               path: google.maps.SymbolPath.CIRCLE,
                               fillOpacity: 0.4,
                               fillColor: couleur,
                               strokeOpacity: 1,
                               strokeWeight: 1,
                               strokeColor: '#333',
                               // echelle[client]
                               scale:   echelle_valeur// trouver une formaule en fonction du CA pour qu'il s''affiche dans le cercle .ex:(Math.sqrt(clients[client].CA) / 100)
                             };
                              //console.log("sscale="+echelle[client])
                             var gMarker = new google.maps.Marker({
                               map: map,
                               position: results[0].geometry.location,
                               title: address,
                               icon: mIcon,
                               label: {color: 'white', fontSize: '12px', fontWeight: '600',
                               text: client.value+" "}
                             });
                        }
                        else{

                          var address = client.ville + " "+ client.cp  ;
                          console.log("erreur :"+status + "\n l'addresse introuvable est :"+address)
                        }
                      });

                    }
            //  }
          }





      function initMap() {

        var bool_cal=true;
        var id_commercial= null;
        var id_magasin = null;
        var id_sousfamille = null;
        var id_famille = null;

          bool_cal= $("#ca_label").hasClass("active");
          console.log( "bool_ca: "+bool_cal);

          id_commercial= document.forms["representant_form"].elements[0].value;
          if(id_commercial=="null")// car il recupère la valeur du champs en chaine de caractere
              id_commercial=null;

          id_magasin = document.forms["representant_form"].elements[1].value;
          if(id_magasin=="null")// car il recupère la valeur du champs en chaine de caractere
              id_magasin=null;
          console.log("id_magasin: "+id_magasin);

          id_famille = document.forms["famille_form"].elements[0].value;
          if(id_famille=="null")// car il recupère la valeur du champs en chaine de caractere
              id_famille=null;
          console.log("id_famille: "+id_famille);

          id_sousfamille = document.forms["sous_famille_form"].elements[0].value;
          if(id_sousfamille=="null")// car il recupère la valeur du champs en chaine de caractere
              id_sousfamille=null;
          console.log("id_sousfamille : "+id_sousfamille);



          $(document).ready(function() {
/*
              $(".ca").click(function() {
                  updateMap();
              });

              $(".marge").click(function() {
                  updateMap();
              });
              $("marge_label").click(function() {
                console.log("b")
              });
*/

              $(".representant").change(function() {
                  updateMap();
              });

              $(".magasin").change(function() {
                  updateMap();
                });

              $(".famille").change(function() {
                id_famille = document.forms["famille_form"].elements[0].value;
              //charger les sous familles
                    $.ajax({
                      type:"POST",
                      url:"/Geolocalisation/sql_list_sous_fam/",
                      data: {
                        'famille': id_famille
                      },
                      success: function(json_data){
                        var sous_familles = JSON.parse(json_data);
                        // rajouter les sous familles en jquery
                        console.log("sous famille: "+sous_familles)
                        var select = $(" .sous_famille");
                        var html = '<OPTION value="null"> Toutes les sous familles </OPTION>';

                        for( var sous_f in sous_familles){
                          html +='<OPTION value="' + sous_familles[sous_f][0]+'"> '
                                  +  sous_familles[sous_f][1] + '</OPTION>'
                        }
                        select.children().remove();
                        select.append(html);

                      }
                    });

                   updateMap();
                });


              $(".sous_famille").change(function() {
                  updateMap();
                });

          });

        $.ajax({
          type:"POST",
          url:"/dashboard/sql_get_geoloc_data/",
          data: {
            'filter[]': [null, id_commercial, id_magasin, id_sousfamille, id_famille],
            'bool_ca': bool_cal
          },
          success: function(json_data){
            var clients = JSON.parse(json_data);


            // Create the map.
            var map = new google.maps.Map(document.getElementById('map_canvas'), {
              zoom: 6,

              center: {lat: 47.090, lng: 0},
            });

            var echelle = getScale(clients);
            console.log("echelle :"+echelle);

            var geocoder = new google.maps.Geocoder();
          //  geocodeAddress(geocoder, clients,echelle,map)
            for (var client in clients){
            geocodeAddress(geocoder, clients[client],echelle[client],map);
            }
          }
        });


      }
