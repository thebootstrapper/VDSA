//
// $(document).ready(function() {
//   // JQuery code to be added in here.
//
//   $('#id_sql_get_geoloc_data').click(function(event){
//     $.ajax({
//       type:"POST",
//       url:"/dashboard/sql_get_geoloc_data/",
//       data: {
//         'filter[]': [null, null, null, null, null],
//         'bool_ca': true
//       },
//       success: function(json_data){
//         var clients = JSON.parse(json_data);
//         affectData(clients);
//
//       }
//     });
//     return false;
//
//   });
//
// });



// $(document).ready(function() {
//   // JQuery code to be added in here.
//
//
//     $.ajax({
//       type:"POST",
//       url:"/dashboard/sql_get_geoloc_data/",
//       data: {
//         'filter[]': [null, null, null, null, null],
//         'bool_ca': true
//       },
//       success: function(json_data){
//         var clients = JSON.parse(json_data);
//         affectData(clients);
//
//       }
//     });
//     return false;
//
//
// });
