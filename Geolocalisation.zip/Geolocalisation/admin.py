from django.contrib import admin
from Geolocalisation.models import *;




admin.site.register(Commercial)
admin.site.register(Magasinvdsa)
# Register your models here.
